﻿using Kutupane_Yonetim_Sistemi;

Kitap kitap = new Kitap();
Uye uye = new Uye();
uye.Uye_Adi = "serhat";

kitap.Kitap_Ekleme(kitap.Kitap_Adi, kitap.ISBN, kitap.Yazar );
kitap.Kitap_Alma(kitap.Kitap_Adi,uye.Uye_Adi);
kitap.Kitap_Iade_Etme(kitap.Kitap_Adi,uye.Uye_numarasi);
uye.Uye_Kaydetme(uye.Uye_Adi, uye.Uye_numarasi);
