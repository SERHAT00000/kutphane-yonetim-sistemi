﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutupane_Yonetim_Sistemi
{
    public class Kutupane
    {
        public  void Kitap_Ekleme(string Kitap_Adi,int ISBN,string Yazar) 
        {
            
            Console.Write("kitabin ISBN no sunu giriniz: ");
            string isbn = Console.ReadLine();
            ISBN = int.Parse(isbn);
            Console.Write("kitabin yazarını giriniz: ");
            string yazar = Console.ReadLine();
            Yazar = yazar;
            Console.Write("kitabin adını giriniz: ");
            string kitap_Adi = Console.ReadLine();
            Kitap_Adi = kitap_Adi;
            Console.WriteLine("kitabn ISBN si: " + ISBN);
            Console.WriteLine("kitabın yazarı: " + Yazar);
            Console.WriteLine("kitabın adı: " + Kitap_Adi);
            

        }
        public void Kitap_Alma(string Kitap_Adi, string Uye_Adi)
        {
            Console.Write("alınacak kitabın adını giriniz: ");
            string kitap_Adi = Console.ReadLine();
            Kitap_Adi= kitap_Adi;
            Console.Write("kitabi alcak kişinin adi: ");
            string uye_Adi = Console.ReadLine();
            Uye_Adi= uye_Adi;
            Console.WriteLine("Bu " + Kitap_Adi + " adlı kitabı " + Uye_Adi + " adlı kişi aldı.");
        }
        public void Kitap_Iade_Etme(string Kitap_Adi, int Uye_numarasi) 
        { 
            Console.Write("iade edilecek kitabın adını girin: ");
            string kitap_Adi = Console.ReadLine();
            Kitap_Adi = kitap_Adi;

            Console.WriteLine("iade eden kişinin numarasını girin: ");
            string uye_numarasi = Console.ReadLine();
            Uye_numarasi= int.Parse(uye_numarasi);
            Console.WriteLine(Uye_numarasi + " nolu kişi " + Kitap_Adi + " adlı kitabı İade etti");
        }
        public void Uye_Kaydetme(string Uye_Adi, int Uye_numarasi) 
        { 
            Console.WriteLine("kaydı yapıalcak kişinin adını giriniz: ");
            string uye_Adi = Console.ReadLine();
            Uye_Adi = uye_Adi;
            Console.WriteLine("kaydı yapılacak kişinin no sunu giriniz: ");
            string uye_numarasi = Console.ReadLine();
            int Uye_Numarasi = int.Parse(uye_numarasi);
            Uye_numarasi = Uye_Numarasi;
            Console.WriteLine(uye_Adi+" isimle "+Uye_numarasi+" nolu kayıt oluşturuldu.");

        }
    }
}
