﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutupane_Yonetim_Sistemi
{
    public class Uye : Kutupane
    {
        public string Uye_Adi { get; set; }
        public int Uye_numarasi { get; set; }

    }
}
