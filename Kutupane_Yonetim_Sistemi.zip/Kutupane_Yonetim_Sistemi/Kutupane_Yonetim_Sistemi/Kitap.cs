﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutupane_Yonetim_Sistemi
{
    public class Kitap : Kutupane
    {
        public int ISBN { get; set; }
        public string Kitap_Adi { get; set; }

        public string Yazar { get; set; }
    }
}
